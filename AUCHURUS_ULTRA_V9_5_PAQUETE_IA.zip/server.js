// AUCHURUS ULTRA V9.5 — backend seguro de ejemplo
// Requiere Node.js 18+
// No pongas la API key en el HTML ni la publiques en GitHub.
import express from "express";
import cors from "cors";

const app = express();
app.use(express.json({ limit: "32kb" }));

// En producción, limita origin a la URL exacta donde publiques Auchurus.
const allowedOrigin = process.env.ALLOWED_ORIGIN || "*";
app.use(cors({ origin: allowedOrigin }));

app.get("/health", (_req, res) => res.json({ ok: true, app: "AUCHURUS ULTRA V9.5" }));

app.post("/api/chat", async (req, res) => {
  try {
    const apiKey = process.env.OPENAI_API_KEY;
    if (!apiKey) return res.status(503).json({ error: "Falta configurar OPENAI_API_KEY en el servidor." });

    const messages = Array.isArray(req.body?.messages) ? req.body.messages : [];
    const system = typeof req.body?.system === "string" ? req.body.system : "Eres Auchurus, un asistente útil y honesto. Responde en español salvo que te hablen en otro idioma.";
    const safeMessages = messages
      .filter(m => m && ["user", "assistant"].includes(m.role) && typeof m.content === "string")
      .slice(-14)
      .map(m => ({ role: m.role, content: m.content.slice(0, 6000) }));

    if (!safeMessages.length || safeMessages[safeMessages.length - 1].role !== "user") {
      return res.status(400).json({ error: "No hay una pregunta válida." });
    }

    const upstream = await fetch(process.env.AI_API_URL || "https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.AI_MODEL || "gpt-4o-mini",
        messages: [{ role: "system", content: system }, ...safeMessages],
        temperature: 0.7
      })
    });

    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      console.error("Proveedor IA respondió:", upstream.status, data?.error?.message || "sin detalle");
      return res.status(502).json({ error: "El proveedor de IA no pudo completar la respuesta." });
    }

    const reply = data?.choices?.[0]?.message?.content;
    if (typeof reply !== "string" || !reply.trim()) {
      return res.status(502).json({ error: "El proveedor devolvió una respuesta vacía." });
    }
    return res.json({ reply: reply.trim() });
  } catch (err) {
    console.error("Error backend:", err?.message || err);
    return res.status(500).json({ error: "Error interno del backend." });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`Auchurus backend escuchando en puerto ${port}`));
